<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    use HasFactory;

    // WAJIB karena nama tabel kamu 'book' (bukan 'books')
    protected $table = 'book';

    // Field yang boleh diisi mass assignment
    protected $fillable = [
        'code',
        'title',
        'author',
        'stock'
    ];

    // RELASI: satu buku bisa dipinjam berkali-kali
    public function pinjams()
    {
        return $this->hasMany(Pinjam::class, 'book_id');
    }
}