<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;

class MemberController extends Controller
{
    public function index(Request $request)
    {
        // Tambahkan validasi role untuk keamanan
        if (auth()->user()->role !== 'member') {
            abort(403, 'Unauthorized access.');
        }
        
        $books = Book::where('stock', '>', 0)->get(); // Hanya tampilkan buku yang tersedia
        
        return view('member.dashboard', compact('books'));
    }
}