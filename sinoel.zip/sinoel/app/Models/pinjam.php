<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Pinjam extends Model
{
    use HasFactory;

    // WAJIB karena nama tabel kamu 'pinjam' (bukan 'pinjams')
    protected $table = 'pinjam';

    protected $fillable = [
        'book_id',
        'user_id',
        'tanggal_pinjam',
        'tanggal_kembali',
        'tanggal_batas',
        'status'
    ];

    // RELASI
    public function book()
    {
        return $this->belongsTo(Book::class, 'book_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    // AUTO ISI TANGGAL BATAS = +7 hari
    protected static function booted()
    {
        static::creating(function ($pinjam) {
            $pinjam->tanggal_batas = Carbon::parse($pinjam->tanggal_pinjam)->addDays(7);
        });
    }

    // // FUNGSI HITUNG DENDA (1000 / hari telat)
    // public function hitungDenda()
    // {
    //     if (!$this->tanggal_kembali) return 0;

    //     $selisih = Carbon::parse($this->tanggal_kembali)
    //                     ->diffInDays($this->tanggal_batas, false);

    //     return $selisih < 0 ? abs($selisih) * 1000 : 0;
    // }
}
