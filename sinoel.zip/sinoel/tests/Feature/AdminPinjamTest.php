<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Book;
use App\Models\Pinjam;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Carbon\Carbon;

class AdminPinjamTest extends TestCase
{
    use RefreshDatabase;

    protected $admin;
    protected $member;
    protected $book;

    protected function setUp(): void
    {
        parent::setUp();

        // Buat admin
        $this->admin = User::factory()->create([
            'role' => 'admin'
        ]);

        // Buat member
        $this->member = User::factory()->create([
            'role' => 'member'
        ]);

        // Buat buku
        $this->book = Book::create([
            'code' => 'BK001',
            'title' => 'Laravel Testing',
            'author' => 'Noel',
            'stock' => 5
        ]);
    }

    /**
     * Admin bisa meminjamkan buku ke member
     */
    public function test_admin_can_create_pinjam()
    {
        $response = $this->actingAs($this->admin)
            ->post('/admin/pinjam', [
                'user_id' => $this->member->id,
                'book_id' => $this->book->id,
            ]);

        $response->assertStatus(302); // redirect back

        $this->assertDatabaseHas('pinjam', [
            'user_id' => $this->member->id,
            'book_id' => $this->book->id,
            'status'  => 'dipinjam'
        ]);

        $this->assertDatabaseHas('book', [
            'id' => $this->book->id,
            'stock' => 4 // 5 - 1
        ]);
    }

    /**
     * Tidak bisa meminjam jika stok 0
     */
    public function test_cannot_borrow_if_stock_zero()
    {
        $this->book->update(['stock' => 0]);

        $response = $this->actingAs($this->admin)
            ->post('/admin/pinjam', [
                'user_id' => $this->member->id,
                'book_id' => $this->book->id,
            ]);

        $response->assertSessionHas('error');

        $this->assertDatabaseMissing('pinjam', [
            'book_id' => $this->book->id
        ]);
    }

    /**
     * Admin bisa mengembalikan buku
     */
    public function test_admin_can_return_book()
    {
        $pinjam = Pinjam::create([
            'user_id' => $this->member->id,
            'book_id' => $this->book->id,
            'tanggal_pinjam' => Carbon::now(),
            'tanggal_batas' => Carbon::now()->addDays(7),
            'status' => 'dipinjam'
        ]);

        $this->book->decrement('stock'); // simulasi dipinjam

        $response = $this->actingAs($this->admin)
            ->post("/admin/kembali/{$pinjam->id}");

        $response->assertSessionHas('success');

        $this->assertDatabaseHas('pinjam', [
            'id' => $pinjam->id,
            'status' => 'kembali'
        ]);

        $this->assertNotNull($pinjam->fresh()->tanggal_kembali);

        $this->assertDatabaseHas('book', [
            'id' => $this->book->id,
            'stock' => 5 // kembali naik
        ]);
    }

    /**
     * Tidak bisa mengembalikan buku yang sudah kembali
     */
    public function test_cannot_return_book_twice()
    {
        $pinjam = Pinjam::create([
            'user_id' => $this->member->id,
            'book_id' => $this->book->id,
            'tanggal_pinjam' => Carbon::now(),
            'tanggal_batas' => Carbon::now()->addDays(7),
            'tanggal_kembali' => Carbon::now(),
            'status' => 'kembali'
        ]);

        $response = $this->actingAs($this->admin)
            ->post("/admin/kembali/{$pinjam->id}");

        $response->assertSessionHas('error');
    }
}
