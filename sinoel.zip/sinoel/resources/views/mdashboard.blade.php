@extends('layouts.app')
@section('content')
<div class="container mx-auto px-4">
    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
            {{ session('success') }}
        </div>
    @endif
    
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">📚 Book Catalog</h2>
        <span class="bg-blue-500 text-white px-3 py-1 rounded-full text-sm">
            <i class="fas fa-user mr-1"></i>Member Mode
        </span>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        @foreach($books as $b)
        <div class="bg-white p-6 rounded-xl shadow hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
            <img src="https://picsum.photos/300/200?random={{$b->id}}" 
                 class="rounded-lg mb-4 w-full h-48 object-cover">
            <h3 class="font-bold text-lg mb-1">{{$b->title}}</h3>
            <p class="text-gray-600 text-sm mb-2">
                <i class="fas fa-user-pen mr-1"></i>{{$b->author}}
            </p>
            <div class="flex justify-between items-center">
                <span class="text-xs px-3 py-1 rounded-full 
                    {{ $b->stock > 5 ? 'bg-green-100 text-green-800' : ($b->stock > 0 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800') }}">
                    Stock: {{$b->stock}}
                </span>
                
            </div>
        </div>
        @endforeach
        
        @if($books->isEmpty())
        <div class="col-span-full text-center py-12">
            <i class="fas fa-book-open text-gray-300 text-6xl mb-4"></i>
            <h3 class="text-xl font-semibold text-gray-500">No books available</h3>
            <p class="text-gray-400 mt-2">Check back later for new arrivals</p>
        </div>
        @endif
    </div>
</div>
@endsection