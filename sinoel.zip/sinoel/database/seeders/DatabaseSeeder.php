<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\book;
use App\Models\pinjam;
use Carbon\Carbon; 

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        User::create([
            'name' => 'Admin Noel',
            'email' => 'admin@noel.com',
            'password' => Hash::make('admin123'),
            'phone' => '081234567890',
            'role' => 'admin',
            'email_verified_at' => now(),
            ]);
        
        User::create([
            'name' => 'krissianto',
            'email' => 'krissianto@noel.com',
            'password' => Hash::make('kris123'),
            'phone' => '089912345678',
            'role' => 'member',
            'email_verified_at' => now(),

        ]);
         User::create([
            'name' => 'nissi',
            'email' => 'nissi@noel.com',
            'password' => Hash::make('nissi123'),
            'phone' => '087722334455',
            'role' => 'member',
            'email_verified_at' => now(),
        ]);

        Book::insert([
            [
                'code'=>'BK001',
                'title'=>'Pemrograman Laravel',
                'author'=>'Rawesvy Kirn',
                'stock'=>5
            ],
            [
                'code'=>'BK002',
                'title'=>'Basis Data MySQL',
                'author'=>'Promigate Toen',
                'stock'=>3
            ],
            [
                'code'=>'BK003',
                'title'=>'Algoritma & Struktur Data',
                'author'=>'Yownita Yesua',
                'stock'=>4
            ],
            [
                'code'=>'BK004',
                'title'=>'Pemrograman Security',
                'author'=>'Rivaldo Nathan',
                'stock'=>2
            ],
            [
                'code'=>'BK005',
                'title'=>'Basis Data Gant Chart',
                'author'=>'Keminsky Eregate',
                'stock'=>7
            ]
        ]);

        Pinjam::create([
            'book_id'=>1,
            'user_id'=>2, // user krissianto
            'tanggal_pinjam'=>Carbon::now()->subDays(10),
            'tanggal_batas'=>Carbon::now()->subDays(3),
            'tanggal_kembali'=>Carbon::now(),
            'status'=>'kembali'
        ]);
        
    }
}
