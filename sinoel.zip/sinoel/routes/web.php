
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\AdminController;
use App\Models\book;
use App\Models\pinjam;
use App\Models\User;


Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/login', [LoginController::class, 'show'])->name('login');
Route::post('/login', [LoginController::class, 'process'])->name('login.process');



Route::middleware(['auth'])->group(function () {

    Route::get('/dashboard', function () {

        if (auth()->user()->role === 'admin') {
            
            $totalDipinjam = Pinjam::where('status', 'dipinjam')->count();
            
            $pinjams = Pinjam::with('user', 'book')
                        ->orderBy('created_at', 'desc')
                        ->get();

            return view('adashboard', [
                'books'   => Book::all(),
                'pinjams' => $pinjams,
                'users'   => User::where('role','member')->get(),
                'totalDipinjam' => $totalDipinjam
            ]);
        }

        return view('mdashboard', [
            'books' => Book::all()
        ]);

    })->name('dashboard');
     Route::post('/admin/pinjam', [AdminController::class, 'pinjam'])
        ->name('admin.pinjam');

    Route::post('/admin/pinjam', [AdminController::class, 'storePinjam'])
        ->name('admin.pinjam');

    Route::post('/admin/kembali/{id}', [AdminController::class, 'kembali'])
        ->name('admin.kembali');
    
        Route::post('/admin/member', [AdminController::class, 'storeMember'])
        ->name('admin.member.store');


    Route::get('/logout', [LoginController::class, 'logout'])->name('logout');
});



