@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4">

    <!-- HEADER -->
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">📊 Admin Dashboard</h2>
        <span class="bg-red-500 text-white px-3 py-1 rounded-full text-sm">
            Admin Mode
        </span>
    </div>
    <div class="flex justify-between items-center mb-4">
        <h3 class="text-xl font-bold">👥 Daftar Member</h3>

        <button onclick="document.getElementById('modalMember').classList.remove('hidden')"
             class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
             + Tambah Member
        </button>
    </div>


    <!-- ALERT -->
    @if(session('success'))
        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
            {{ session('error') }}
        </div>
    @endif

    <!-- STATS -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div class="bg-white p-6 rounded-xl shadow">
            <p class="text-gray-500 text-sm">Total Books</p>
            <p class="text-2xl font-bold">{{ $books->count() }}</p>
        </div>

        <div class="bg-white p-6 rounded-xl shadow">
            <p class="text-gray-500 text-sm">Books Dipinjam</p>
            <p class="text-2xl font-bold">{{ $totalDipinjam }}</p>
        </div>


        <div class="bg-white p-6 rounded-xl shadow">
            <p class="text-gray-500 text-sm">Members</p>
            <p class="text-2xl font-bold">{{ $users->count() }}</p>
        </div>
    </div>

    <!-- FORM PINJAM -->
    <div class="bg-white rounded-xl shadow p-6 mb-8">
        <h3 class="text-xl font-bold mb-4">➕ Input Peminjaman</h3>

        <form action="{{ route('admin.pinjam') }}" method="POST" class="grid grid-cols-1 md:grid-cols-3 gap-4">
            @csrf

            <select name="user_id" class="border rounded px-3 py-2" required>
                <option value="">Pilih Member</option>
                @foreach($users as $u)
                <option value="{{ $u->id }}">
                    {{ $u->name }} - {{ $u->phone }}
                </option>
                @endforeach
            </select>

            <select name="book_id" class="border rounded px-3 py-2" required>
                <option value="">Pilih Buku</option>
                @foreach($books as $b)
                    @if($b->stock > 0)
                        <option value="{{ $b->id }}">
                            {{ $b->title }} (Stock: {{ $b->stock }})
                        </option>
                    @endif
                @endforeach
            </select>

            <button class="bg-blue-600 text-white rounded px-4 py-2 hover:bg-blue-700">
                Simpan
            </button>
        </form>
    </div>

    <!-- TABLE PINJAMAN -->
    <div class="bg-white rounded-xl shadow p-6">
        <h3 class="text-xl font-bold mb-4">📋 Buku Sedang Dipinjam</h3>

        <table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-50">
        <tr>
            <th class="px-4 py-2">Member</th>
            <th class="px-4 py-2">Buku</th>
            <th class="px-4 py-2">Tgl Pinjam</th>
            <th class="px-4 py-2">Batas Kembali</th>
            <th class="px-4 py-2">Tgl Dikembalikan</th>
            <th class="px-4 py-2">Status</th>
            <th class="px-4 py-2">Aksi</th>
        </tr>
    </thead>
    <tbody>
        @forelse($pinjams as $p)
        <tr class="border-t">
            <td class="px-4 py-2">{{ $p->user->name }}</td>
            <td class="px-4 py-2">{{ $p->book->title }}</td>
            <td class="px-4 py-2">{{ $p->tanggal_pinjam }}</td>
            <td class="px-4 py-2">{{ $p->tanggal_batas }}</td>
            <td>
                @if($p->tanggal_kembali)
                    <span class="text-green-700">
                        {{ $p->tanggal_kembali }}
                    </span>
                @else
                    <span class="text-gray-400 italic">
                        Belum dikembalikan
                    </span>
                @endif
            </td>
            <td class="px-4 py-2">
                @if($p->status === 'dipinjam')
                    <span class="bg-yellow-100 text-yellow-700 px-2 py-1 rounded text-sm">
                 Dipinjam
                    </span>
                @else
                    <span class="bg-green-100 text-green-700 px-2 py-1 rounded text-sm">
                Dikembalikan
                     </span>
                @endif
            </td>


<td class="px-4 py-2">
    @if($p->status === 'dipinjam')
        <form action="{{ route('admin.kembali', $p->id) }}" method="POST">
            @csrf
            <button
                onclick="return confirm('Yakin buku dikembalikan?')"
                class="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700">
                Dikembalikan
            </button>
        </form>
    @else
        <span class="text-gray-400 italic text-sm">
            Selesai
        </span>
    @endif
</td>

        </tr>
        @empty
        <tr>
            <td colspan="6" class="text-center py-4 text-gray-500">
                Tidak ada buku dipinjam
            </td>
        </tr>
        @endforelse
    </tbody>
</table>

    </div>
<div id="modalMember"
     class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">

    <div class="bg-white w-full max-w-md rounded-xl p-6">
        <h3 class="text-lg font-bold mb-4">Tambah Member Baru</h3>

        <form action="{{ route('admin.member.store') }}" method="POST" class="space-y-3">
            @csrf

            <input type="text" name="name" placeholder="Nama"
                class="w-full border rounded px-3 py-2" required>

            <input type="email" name="email" placeholder="Email"
                class="w-full border rounded px-3 py-2" required>

            <input type="password" name="password" placeholder="Password"
                class="w-full border rounded px-3 py-2" required>

            <input type="text" name="phone" placeholder="No HP"
                class="w-full border rounded px-3 py-2" required>

            <div class="flex justify-end gap-2 mt-4">
                <button type="button"
                    onclick="document.getElementById('modalMember').classList.add('hidden')"
                    class="px-4 py-2 border rounded">
                    Batal
                </button>

                <button class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                    Simpan
                </button>
            </div>
        </form>
    </div>
</div>

</div>
@endsection
