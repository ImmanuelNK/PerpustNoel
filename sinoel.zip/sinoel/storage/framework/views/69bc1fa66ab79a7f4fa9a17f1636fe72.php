<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | Perpustakaan Noel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        .bg-wallpaper {
            background-image: url("https://images.unsplash.com/photo-1524995997946-a1c2e315a42f");
            background-size: cover;
            background-position: center;
        }
    </style>
</head>
<body class="min-h-screen flex">

    <!-- LEFT SIDE (LOGIN FORM) -->
    <div class="w-full lg:w-1/2 flex items-center justify-center bg-gray-50">
        <div class="w-full max-w-md p-10">

            <div class="mb-6">
                <h1 class="text-3xl font-bold text-gray-800">📚 Perpustakaan Noel</h1>
                <p class="text-gray-500 mt-1">Welcome back, please login</p>
            </div>

            <?php if(session('error')): ?>
                <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-5">
                <?php echo csrf_field(); ?>

                <div>
                    <label class="text-sm text-gray-600">Email / Username</label>
                    <input type="text" name="email" required
                        class="w-full px-4 py-3 mt-1 border rounded-lg focus:ring focus:ring-blue-300">
                </div>

                <div>
                    <label class="text-sm text-gray-600">Password</label>
                    <input type="password" name="password" required
                        class="w-full px-4 py-3 mt-1 border rounded-lg focus:ring focus:ring-blue-300">
                </div>

                <button type="submit"
                    class="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                    Login
                </button>
            </form>

        </div>
    </div>

    <!-- RIGHT SIDE (WALLPAPER) -->
    <div class="hidden lg:flex w-1/2 bg-wallpaper relative">

        <!-- Overlay -->
        <div class="absolute inset-0 bg-blue-900 bg-opacity-70"></div>

        <!-- Text -->
        <div class="relative z-10 flex flex-col items-center justify-center text-white text-center p-10">
            <h2 class="text-4xl font-bold mb-4">Manage Your Library</h2>
            <p class="text-lg text-blue-100">
                Perpustakaan terhebat, terlengkap, dan termudah hanya di PERPUSTAKAAN NOEL! 
            </p>
        </div>

    </div>

</body>
</html>
<?php /**PATH C:\Users\noeln\sinoel\resources\views/login.blade.php ENDPATH**/ ?>