<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\Book;
use App\Models\Pinjam;
use App\Models\User;
use Carbon\Carbon;


class AdminController extends Controller
{
    public function index(){
        return view('adashboard',[
            'books'=>Book::all(),
            'users'   => User::where('role', 'member')->get(),
            'pinjams'=>Pinjam::with('user','book')->where('status', 'dipinjam')->get()
        ]);
    }
     public function storePinjam(Request $request)
    {
        $request->validate([
            'user_id' => 'required',
            'book_id' => 'required'
        ]);

        $book = Book::findOrFail($request->book_id);

        if ($book->stock <= 0) {
            return back()->with('error', 'Stock buku habis!');
        }

        Pinjam::create([
            'user_id'        => $request->user_id,
            'book_id'        => $request->book_id,
            'tanggal_pinjam' => Carbon::now(),
            'status'         => 'dipinjam'
        ]);

        $book->decrement('stock');

        return back()->with('success', 'Buku berhasil dipinjam');
    }
    public function kembali($id)
    {
        $pinjam = Pinjam::with('book')->findOrFail($id);

        if ($pinjam->status === 'kembali') {
            return back()->with('error', 'Buku sudah dikembalikan');
        }

        // UPDATE STATUS
        $pinjam->update([
            'status' => 'kembali',
            'tanggal_kembali' => Carbon::now()
        ]);

        // TAMBAH STOCK
        $pinjam->book->increment('stock');

        return back()->with('success', 'Buku telah dikembalikan');
    }

    public function storeMember(Request $request)
    {
    $request->validate([
        'name'     => 'required',
        'email'    => 'required|email|unique:users',
        'password' => 'required|min:4',
        'phone'    => 'required'
    ]);

    User::create([
        'name'     => $request->name,
        'email'    => $request->email,
        'password' => Hash::make($request->password),
        'phone'    => $request->phone,
        'role'     => 'member'
    ]);

    return back()->with('success', 'Member baru berhasil ditambahkan');
    }
}
