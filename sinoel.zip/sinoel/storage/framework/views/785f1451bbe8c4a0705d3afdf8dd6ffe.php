

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4">

    <!-- HEADER -->
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">📊 Admin Dashboard</h2>
        <span class="bg-red-500 text-white px-3 py-1 rounded-full text-sm">
            Admin Mode
        </span>
    </div>
    <div class="flex justify-between items-center mb-4">
        <h3 class="text-xl font-bold">👥 Daftar Member</h3>

        <button onclick="document.getElementById('modalMember').classList.remove('hidden')"
             class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
             + Tambah Member
        </button>
    </div>


    <!-- ALERT -->
    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <!-- STATS -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div class="bg-white p-6 rounded-xl shadow">
            <p class="text-gray-500 text-sm">Total Books</p>
            <p class="text-2xl font-bold"><?php echo e($books->count()); ?></p>
        </div>

        <div class="bg-white p-6 rounded-xl shadow">
            <p class="text-gray-500 text-sm">Books Dipinjam</p>
            <p class="text-2xl font-bold"><?php echo e($totalDipinjam); ?></p>
        </div>


        <div class="bg-white p-6 rounded-xl shadow">
            <p class="text-gray-500 text-sm">Members</p>
            <p class="text-2xl font-bold"><?php echo e($users->count()); ?></p>
        </div>
    </div>

    <!-- FORM PINJAM -->
    <div class="bg-white rounded-xl shadow p-6 mb-8">
        <h3 class="text-xl font-bold mb-4">➕ Input Peminjaman</h3>

        <form action="<?php echo e(route('admin.pinjam')); ?>" method="POST" class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <?php echo csrf_field(); ?>

            <select name="user_id" class="border rounded px-3 py-2" required>
                <option value="">Pilih Member</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($u->id); ?>">
                    <?php echo e($u->name); ?> - <?php echo e($u->phone); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select name="book_id" class="border rounded px-3 py-2" required>
                <option value="">Pilih Buku</option>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($b->stock > 0): ?>
                        <option value="<?php echo e($b->id); ?>">
                            <?php echo e($b->title); ?> (Stock: <?php echo e($b->stock); ?>)
                        </option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button class="bg-blue-600 text-white rounded px-4 py-2 hover:bg-blue-700">
                Simpan
            </button>
        </form>
    </div>

    <!-- TABLE PINJAMAN -->
    <div class="bg-white rounded-xl shadow p-6">
        <h3 class="text-xl font-bold mb-4">📋 Buku Sedang Dipinjam</h3>

        <table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-50">
        <tr>
            <th class="px-4 py-2">Member</th>
            <th class="px-4 py-2">Buku</th>
            <th class="px-4 py-2">Tgl Pinjam</th>
            <th class="px-4 py-2">Batas Kembali</th>
            <th class="px-4 py-2">Tgl Dikembalikan</th>
            <th class="px-4 py-2">Status</th>
            <th class="px-4 py-2">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $pinjams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="border-t">
            <td class="px-4 py-2"><?php echo e($p->user->name); ?></td>
            <td class="px-4 py-2"><?php echo e($p->book->title); ?></td>
            <td class="px-4 py-2"><?php echo e($p->tanggal_pinjam); ?></td>
            <td class="px-4 py-2"><?php echo e($p->tanggal_batas); ?></td>
            <td>
                <?php if($p->tanggal_kembali): ?>
                    <span class="text-green-700">
                        <?php echo e($p->tanggal_kembali); ?>

                    </span>
                <?php else: ?>
                    <span class="text-gray-400 italic">
                        Belum dikembalikan
                    </span>
                <?php endif; ?>
            </td>
            <td class="px-4 py-2">
                <?php if($p->status === 'dipinjam'): ?>
                    <span class="bg-yellow-100 text-yellow-700 px-2 py-1 rounded text-sm">
                 Dipinjam
                    </span>
                <?php else: ?>
                    <span class="bg-green-100 text-green-700 px-2 py-1 rounded text-sm">
                Dikembalikan
                     </span>
                <?php endif; ?>
            </td>


<td class="px-4 py-2">
    <?php if($p->status === 'dipinjam'): ?>
        <form action="<?php echo e(route('admin.kembali', $p->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button
                onclick="return confirm('Yakin buku dikembalikan?')"
                class="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700">
                Dikembalikan
            </button>
        </form>
    <?php else: ?>
        <span class="text-gray-400 italic text-sm">
            Selesai
        </span>
    <?php endif; ?>
</td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6" class="text-center py-4 text-gray-500">
                Tidak ada buku dipinjam
            </td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

    </div>
<div id="modalMember"
     class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">

    <div class="bg-white w-full max-w-md rounded-xl p-6">
        <h3 class="text-lg font-bold mb-4">Tambah Member Baru</h3>

        <form action="<?php echo e(route('admin.member.store')); ?>" method="POST" class="space-y-3">
            <?php echo csrf_field(); ?>

            <input type="text" name="name" placeholder="Nama"
                class="w-full border rounded px-3 py-2" required>

            <input type="email" name="email" placeholder="Email"
                class="w-full border rounded px-3 py-2" required>

            <input type="password" name="password" placeholder="Password"
                class="w-full border rounded px-3 py-2" required>

            <input type="text" name="phone" placeholder="No HP"
                class="w-full border rounded px-3 py-2" required>

            <div class="flex justify-end gap-2 mt-4">
                <button type="button"
                    onclick="document.getElementById('modalMember').classList.add('hidden')"
                    class="px-4 py-2 border rounded">
                    Batal
                </button>

                <button class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                    Simpan
                </button>
            </div>
        </form>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\noeln\sinoel\resources\views/adashboard.blade.php ENDPATH**/ ?>